package webb;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;


public class Chrome {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		WebDriver d=new ChromeDriver();
		String b="http://www.google.com";
		
		d.get(b);
		Thread.sleep(1000);
		d.get("http://talent.capgemini.com");
		
	}

}
